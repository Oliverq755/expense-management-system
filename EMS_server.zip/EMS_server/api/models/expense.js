const mongoose = require('mongoose');

const expenseSchema = mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    expenseCategory: String,
    itemName: String,
    amount: Number,
    expenseDate: String,
});

module.exports = mongoose.model('Expense', expenseSchema);