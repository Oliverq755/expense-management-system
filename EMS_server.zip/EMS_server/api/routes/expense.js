const express = require("express");
const router = express.Router();
const mongoose = require("mongoose");

const Expense = require("../models/expense");

router.get("/", (req, res, next) => {
    Expense.find()
        .exec()
        .then(docs => {
            // console.log(docs,'docs');
              if (docs.length > 0) {
            res.status(200).json(docs);
              } else {
                  res.status(404).json({ 
                      message: 'No entries found'
                  });
              }
        })
        .catch(err => {
            console.log(err);
            res.status(500).json({
                error: err
            });
        });
});

router.post("/", (req, res, next) => {
    console.log(req);
    const expense = new Expense({
        _id: new mongoose.Types.ObjectId(),
        amount: req.body.EXPENSE_AMOUNT,
        expenseCategory: req.body.EXPENSE_CATEGORY,
        expenseDate: req.body.EXPENSE_DATE,
        itemName: req.body.EXPENSE_ITEM_NAME
    });
    expense
        .save()
        .then(result => {
            res.status(201).json({
                message: "Handling POST requests to /expense",
                createdProduct: result
            });
        })
        .catch(err => {
            console.log(err);
            res.status(500).json({
                error: err
            });
        });
});

router.get("/:category", (req, res, next) => {
    // console.log(req.params)
    const id = req.params.movieName;
    Movies.find({movieName:id})
        .exec()
        .then(doc => {
            console.log("From database", doc);
            if (doc) {
                res.status(200).json(doc);
            } else {
                res
                    .status(404)
                    .json({ message: "No valid entry found for provided ID" });
            }
        })
        .catch(err => {
            console.log(err);
            res.status(500).json({ error: err });
        });
});

router.get("/:expenseId", (req, res, next) => {
    const id = req.params.expenseId;
    const updateOps = {};
    for (const ops of req.body) {
        updateOps[ops.propName] = ops.value;
    }
    Product.update({ _id: id }, { $set: updateOps })
        .exec()
        .then(result => {
            console.log(result);
            res.status(200).json(result);
        })
        .catch(err => {
            console.log(err);
            res.status(500).json({
                error: err
            });
        });
});

router.delete("/:expenseId", (req, res, next) => {
    const id = req.params.expenseId;
    Product.remove({ _id: id })
        .exec()
        .then(result => {
            res.status(200).json(result);
        })
        .catch(err => {
            console.log(err);
            res.status(500).json({
                error: err
            });
        });
});

module.exports = router;